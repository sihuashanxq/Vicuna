﻿namespace Vicuna.Engine
{
    public enum DBOperationFlags
    {
        Ok,

        Err,

        Wait,

        Dead
    }
}

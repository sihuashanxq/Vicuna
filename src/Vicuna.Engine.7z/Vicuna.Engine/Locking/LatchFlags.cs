﻿namespace Vicuna.Engine.Locking
{
    public enum LatchFlags : byte
    {
        Read = 0,

        Write = 1
    }
}

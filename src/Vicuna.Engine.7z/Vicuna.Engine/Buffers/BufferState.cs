﻿namespace Vicuna.Engine.Buffers
{
    public enum BufferState
    {
        Clean,

        Dirty,

        NoneLoading
    }
}

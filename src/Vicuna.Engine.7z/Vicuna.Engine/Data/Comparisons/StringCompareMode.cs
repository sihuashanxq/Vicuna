﻿namespace Vicuna.Engine.Data
{
    public enum StringCompareMode
    {
        None = 0,
     
        IgnoreCase = 1
    }
}

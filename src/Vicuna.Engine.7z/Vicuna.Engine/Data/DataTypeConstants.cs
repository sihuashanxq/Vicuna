﻿namespace Vicuna.Engine.Data
{
    public static class DataTypeConstants
    {
        public const byte DataTypeMask = 0x3F;

        public const byte DataSizeMask = 0xC0;
    }
}

﻿namespace Vicuna.Engine.Data.Tables
{
    public class TableSchmea
    {

    }
}

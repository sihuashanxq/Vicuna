namespace Vicuna.Engine.Data.Trees
{
    public partial class Tree
    {
        
    }
}
﻿namespace Vicuna.Engine.Data.Trees 
{
    public enum TreeNodeHeaderFlags : byte 
    {
        Primary = 1,

        Data = 2,

        Page = 3
    }
}
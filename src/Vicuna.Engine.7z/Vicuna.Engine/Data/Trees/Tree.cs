﻿using Vicuna.Engine.Data.Tables;
using Vicuna.Engine.Data.Trees.Fixed;
using Vicuna.Engine.Paging;

namespace Vicuna.Engine.Data.Trees
{
    public enum TableIndexType
    {
        Cluster,

        Unique,

        Universale
    }

    public struct TableIndexSchema
    {
        public Tree Tree;

        public TableIndexType Type;

        public bool IsUnique => Type != TableIndexType.Universale;

        public bool IsCluster => Type == TableIndexType.Cluster;
    }

    public partial class Tree
    {
        private readonly Index _index;

        private readonly TreeRootHeader _root;

        private readonly PageAllocator _pageAllocator;

        public const ushort MaxEntrySizeInPage = (Constants.PageSize - Constants.PageHeaderSize - Constants.PageFooterSize) / 2 - TreeNodeHeader.SizeOf - TreeNodeTransactionHeader.SizeOf;

        public Tree(Index index, TreeRootHeader root, PageAllocator pageAllocator)
        {
            _root = root;
            _index = index;
            _pageAllocator = pageAllocator;
        }
    }
}

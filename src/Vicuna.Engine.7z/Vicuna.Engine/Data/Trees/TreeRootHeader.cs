﻿using System.Runtime.InteropServices;
using Vicuna.Engine.Data.Trees.Fixed;
using Vicuna.Engine.Paging;

namespace Vicuna.Engine.Data.Trees
{
    [StructLayout(LayoutKind.Explicit, Pack = 1, Size = SizeOf)]
    public unsafe struct TreeRootHeader
    {
        public const int SizeOf = 12 + FixedSizeTreeRootHeader.SizeOf;

        [FieldOffset(0)]
        public int FileId;

        [FieldOffset(4)]
        public long PageNumber;

        [FieldOffset(12)]
        public FixedSizeTreeRootHeader FreeRootHeader;

        public PagePosition RootPosition => new PagePosition(FileId, PageNumber);
    }
}

﻿namespace Vicuna.Engine.Data
{
    public enum DataSize : byte
    {
        Size_1 = 0x00 << 6,

        Size_2 = 0x01 << 6,

        Size_4 = 0x03 << 6
    }
}

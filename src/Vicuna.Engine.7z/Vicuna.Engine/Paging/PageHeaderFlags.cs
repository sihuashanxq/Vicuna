﻿namespace Vicuna.Engine
{
    public enum PageHeaderFlags : byte
    {
        File,

        BTree,

        Overflow
    }
}
